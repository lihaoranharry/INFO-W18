# showargmuments.py
# 
# Prints out the program arguments that have been passed into this standalone
# application

import sys # We need to import the sys module in order to gain access to the arguments

print("Program arguments:", sys.argv)