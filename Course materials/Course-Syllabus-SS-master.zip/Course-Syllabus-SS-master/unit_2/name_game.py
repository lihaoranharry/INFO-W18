name = input("Enter your name: ")
bname = "B" + name[1:]
print(name + ", " + name + ", bo " + bname)
fname = "F" + name[1:]
print("Banana Fana Fo "+ fname)
